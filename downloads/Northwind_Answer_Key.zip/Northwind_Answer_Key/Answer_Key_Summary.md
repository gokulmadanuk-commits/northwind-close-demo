# Northwind Logistics Ltd: answer key (fictional company)

This is the correct set of books for FY26 (year to 31 March 2026). It was generated **before** any document was created; every document in the sample pack was then rendered from it. Use it to check your own run: your trial balance should match to the penny.

## Key figures
| | £ |
|---|---|
| Revenue and other income | 42,232,637.22 |
| Reported EBITDA | 4,405,559.90 |
| Approved EBITDA adjustments | +37,200.00 |
| Adjusted EBITDA | 4,442,759.90 |
| Profit before tax | 2,718,110.27 |
| Corporation tax estimate (25%) | 679,528 |
| Cash at 31 March 2026 | 3,432,643.21 |
| Loan at 31 March 2026 | 12,000,000.00 |
| Net debt / Adjusted EBITDA | 1.93x (covenant 3.0x) |

## Year-end journals
- **YE1 Cloudnest prepayment**: Prepayment - Cloudnest annual licence: 11 of 12 months (Apr 2026 - Feb 2027) unexpired. Dr 620-Prepayments 88,000.00; Cr 463-ITSoftwareAndConsumables 88,000.00
- **YE2 Grant income recognised**: Clean Freight Pilot grant - recognise 3 of 6 project months (Jan - Mar 2026). Dr 810-IncomeInAdvance 120,000.00; Cr 260-OtherRevenue 120,000.00
- **YE3 Depreciation - new laptops**: Depreciation - 40 laptops (PT-INV-90477): 3 years straight line from month of purchase. Dr 416-Depreciation 1,322.22; Cr 721-LessAccumulatedDepreciationOnComputerEquipment 1,322.22
- **YE4 Corporation tax estimate**: Corporation tax - estimate at 25% of profit before tax (for the tax adviser to confirm). Dr 500-CorporationTax 679,528.00; Cr 830-ProvisionForCorporationTax 679,528.00

## EBITDA adjustments (management reporting only)
- A Sponsor monitoring fee: +150,000.00 (approved). Monitoring agreement: £150,000 a year, billed quarterly. Sponsor cost, not an operating cost of the business.
- B End-of-contract vehicle refurbishment charges: +38,400.00 (approved). One-off charges for 6 vehicles returned at the end of their contracts (fleet renewal).
- C Prior-year fuel volume rebate: -31,200.00 (approved). Rebate relates to FY25 volumes (Apr 2024 - Mar 2025), so it flatters FY26 fuel cost.
- D Clean Freight Pilot grant income: -120,000.00 (approved). Non-recurring grant income. Pilot running costs stay in: the electric vehicles and route optimisation continue after the pilot.
- E Agency temp-to-perm conversion fees: +14,800.00 (declined). CFO view: converting agency staff to permanent is a normal recurring hiring cost - keep it in EBITDA.

## The judgement items and how they were treated
1. Subscription paid on the CFO's personal card (Tillwell): expense claim (801), VAT reclaimed.
2. USD charge (Quillstack): GBP amount on the card statement; 2.99% FX fee to 404 Bank Fees; reverse charge VAT nets to nil.
3. Annual licence (Cloudnest): whole months, £88,000 prepaid.
4. Grant (Rivermouth): £120,000 recognised (3 of 6 project months), £120,000 held in income in advance.
5. Duplicate payment (Tarnfield TS-20515): paid twice on 13 Mar, refunded 24 Mar; nets to nil.
6. Portal-only invoices (Pennant): booked from the portal downloads. The 16-31 Mar invoice is dated 1 April, so the net cost is accrued in March (805) and the VAT falls in the April return.
7. Photographed receipt (Pinmoor trade counter): booked from the photo, VAT £31.07.
8. Standing order with no invoices (Harbourside rent): supported by the lease rent schedule, no VAT.
9. Laptops: capitalised (720), depreciated over 3 years from the month of purchase.
Plus the Kestwick KH-1194 invoice that never reached the inbox: booked from the supplier statement.

## Note on this key
The real run caught one error in the first version of this key: the April-dated Pennant invoice had been booked into March with its VAT. The key now accrues the net cost in March, which is the correct VAT tax-point treatment.

Files: `truth.beancount` (the full ledger with balance assertions; run `bean-check truth.beancount`), `Trial_Balance_2026-03-31.csv`.
