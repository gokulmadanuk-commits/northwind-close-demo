NORTHWIND LOGISTICS LTD - SAMPLE DATA PACK
From inbox to accounts: a year-end close with Claude in Cowork

Everything in this pack is fictional: the company, its people, suppliers, customers, banks and
every document. Names, numbers and addresses are invented; email domains end in .example.
Every document carries a "Fictional company - demo document" footer.

WHAT'S IN THE NORTHWIND FOLDER
  Inbox_Export/      34 emails (.eml): Finance_Inbox, CFO_Inbox and the CFO's personal Gmail
  Statements/        March bank CSV, Feb and Mar card statements, FY25 audited accounts
  ERP_Export/        Feb trial balance, monthly TBs, open AR/AP, March AP already posted,
                     fixed asset register, recurring journals, chart of accounts
  Sales/             March billing summary and the three customer invoices
  Payroll/           March payroll report (password-protected)
  Portal_Downloads/  two fuel invoices that only exist in the supplier's portal
  Phone_Photos/      one photographed till receipt

HOW TO RUN IT
  1. Unzip. Open Cowork in the Claude desktop app and select the Northwind folder.
  2. Run the ten prompts in Prompt_Pack.txt, in order, in one session.
     (They are also on the demo site's "Build it yourself" page, with copy buttons.)
  3. When Claude asks for the payroll password, it is:  NWL-Payroll-2026
  4. When Claude asks judgement questions, answer as the CFO did in our run (below).
  5. Compare your trial balance with the answer key. It should match to the penny.

THE CFO'S ANSWERS IN OUR RUN
  - Tillwell £249 on the CFO's personal card: company cost, reimburse by expense claim, reclaim the VAT.
  - Three personal purchases in the Gmail inbox: personal, leave them out.
  - Quillstack (USD): use the card's GBP amount; the FX fee goes to bank charges.
  - Cloudnest annual licence: whole months, £8,000 in March and £88,000 prepaid.
  - FY27 insurance renewal: invoiced in April, nothing to book.
  - Pennant FY26 rebate: don't accrue; it is only confirmed after the rebate year.
  - Grant: recognise £120,000 (three of six budget months); keep £120,000 in income in advance.
  - Kestwick KH-1194 (on the statement only): book it; leave its VAT off the return until the copy arrives.
  - Ferncroft end-of-contract charges: book them in 324 Vehicle Leases with the other Ferncroft costs.
  - Old FY23 laptops: keep them on the register (redeployed).
  - Corporation tax: book a 25% estimate as a year-end journal.
  - EBITDA adjustments: approve the monitoring fee (+£150,000), end-of-contract charges (+£38,400),
    FY25 fuel rebate (-£31,200) and grant income (-£120,000). Decline pilot vehicle hire and the
    temp-to-perm fees (normal recurring costs).

Questions? Email Gokul: gokulmadan2@gmail.com   ·   linkedin.com/in/gokulmadan   ·   gokulmadan.com
